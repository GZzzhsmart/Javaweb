package com.gs.game;

/**
 * Created by WangGenshen on 12/29/15.
 */
public class Constants {

    public static final int GRID_SIZE = 100;

    public static final int KEY_UP = 38;
    public static final int KEY_DOWN = 40;
    public static final int KEY_LEFT = 37;
    public static final int KEY_RIGHT = 39;

    public static final int KEY_ENTER = 10;

}
