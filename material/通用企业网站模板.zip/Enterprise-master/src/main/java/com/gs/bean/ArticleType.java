package com.gs.bean;

/**
 * Created by WangGenshen on 12/9/16.
 */
public class ArticleType {
    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
