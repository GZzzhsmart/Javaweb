package com.gs.bean;

/**
 * Created by WangGenshen on 12/9/16.
 */
public class Hospital {

    private int id;
    private String level;
    private String name;
    private String address;
    private String telNo;
    private String webAddress;
    private String busLine;
    private double longidute;
    private double laditude;
    private String image;
    private String des;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getWebAddress() {
        return webAddress;
    }

    public void setWebAddress(String webAddress) {
        this.webAddress = webAddress;
    }

    public String getBusLine() {
        return busLine;
    }

    public void setBusLine(String busLine) {
        this.busLine = busLine;
    }

    public double getLongidute() {
        return longidute;
    }

    public void setLongidute(double longidute) {
        this.longidute = longidute;
    }

    public double getLaditude() {
        return laditude;
    }

    public void setLaditude(double laditude) {
        this.laditude = laditude;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
