package com.gs.dao;

import com.gs.bean.Hospital;
import org.springframework.stereotype.Repository;

/**
 * Created by WangGenshen on 5/16/16.
 */
@Repository
public interface HospitalDAO extends BaseDAO<Hospital, String> {

}
