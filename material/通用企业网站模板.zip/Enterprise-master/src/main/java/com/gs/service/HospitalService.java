package com.gs.service;

import com.gs.bean.Hospital;

/**
 * Created by WangGenshen on 5/16/16.
 */
public interface HospitalService extends BaseService<Hospital, String> {

}
