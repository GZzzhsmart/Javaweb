
import junit.framework.TestCase;

/**
 * Created by WangGenshen on 11/28/16.
 */
public class ProductParserTest extends TestCase {

    @Override
    protected void setUp() throws Exception {

    }

}
